# Hikvision Utility  

A Scrypted plugin for controlling Hikvision camera features such as supplemental light (floodlight), audio alarms, and strobe lights.  

## Installation & Configuration
1. Install the `Hikvision Utility` plugin in Scrypted.
2. In the plugin's settings, click add a new device and choose the camera and type of switch to add.  
3. Configure the settings on the switch device page.  